(function () {
  function getDefaultShortcuts() {
    return [
      { key: 'g', url: 'https://google.com/search?q={query}', description: 'Google Search' },
      { key: 'gl helm', url: 'https://gitlab.onefiserv.net/issuers/fscm/gfs-od-helm', description: 'Od-Helm' },
      { key: 'gl dpsmasking', url: 'https://gitlab.onefiserv.net/issuers/dispute/disputesworkspace/is-dps-masking', description: 'Dps-Masking' },
      { key: 'gl dpsadmin', url: 'https://gitlab.onefiserv.net/issuers/dispute/disputesworkspace/is-dps-admin', description: 'Dps-Admin' },
      { key: 'gl cb', url: 'https://gitlab.onefiserv.net/issuers/dispute/disputesworkspace/gfs-dws-fraud-chargeback', description: 'Chargebacks' },
      { key: 'gl ddactionfunction', url: 'https://gitlab.onefiserv.net/issuers/dispute/disputesworkspace/is-dws-disputes-actionfunction', description: 'dd = disputes' },
      { key: 'gl ffactionfunction', url: 'https://gitlab.onefiserv.net/issuers/dispute/disputesworkspace/is-dws-fraud-actionfunction', description: 'ff = fraud' },
      { key: 'gl ddcase', url: 'https://gitlab.onefiserv.net/issuers/dispute/disputesworkspace/gfs-od-disputes-case', description: 'dd = disputes' },
      { key: 'gl ffcase', url: 'https://gitlab.onefiserv.net/issuers/dispute/disputesworkspace/gfs-od-fraud-case', description: 'ff = fraud' },
      { key: 'j', url: 'https://enterprise-jira.onefiserv.net/browse/DAODT-{ticketNumber}', description: 'Jira Ticket' },
    ];
  }

  if (typeof window !== 'undefined') {
    window.getDefaultShortcuts = getDefaultShortcuts;
  }

  const settingsRoot = document.getElementById('allShortcutList');
  if (!settingsRoot) {
    return;
  }

  let shortcuts = [];
  let editingIndex = null;
  const importTextarea = document.getElementById('importTextarea');
  const importBtn = document.getElementById('importBtn');
  const importClearBtn = document.getElementById('importClearBtn');
  const exportBtn = document.getElementById('exportBtn');

  class FadeNotification {
    constructor(element, duration = 3000) {
      this.element = element;
      this.duration = duration;
      this.hideTimeout = null;
      this.fadeTimeout = null;
    }

    show(message = null) {
      this.clear();
      if (message) {
        this.element.textContent = message;
      }
      this.element.classList.add('notification--visible');
      this.hideTimeout = setTimeout(() => this.hide(), this.duration);
    }

    hide() {
      this.element.classList.remove('notification--visible');
    }

    clear() {
      if (this.hideTimeout) {
        clearTimeout(this.hideTimeout);
        this.hideTimeout = null;
      }
      if (this.fadeTimeout) {
        clearTimeout(this.fadeTimeout);
        this.fadeTimeout = null;
      }
    }
  }

  const successNotification = new FadeNotification(
    document.getElementById('successMessage'),
    3000
  );
  const errorNotification = new FadeNotification(
    document.getElementById('errorMessage'),
    4000
  );

  loadShortcuts();

  ['newKey', 'newDesc', 'newUrl'].forEach(id => {
    document.getElementById(id).addEventListener('input', validateForm);
  });

  document.getElementById('addBtn').addEventListener('click', saveShortcut);
  document.getElementById('cancelBtn').addEventListener('click', cancelEdit);

  document.getElementById('newUrl').addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !document.getElementById('addBtn').disabled) {
      saveShortcut();
    }
  });

  if (importTextarea) {
    importTextarea.addEventListener('input', handleImportInputChange);
  }

  if (importBtn) {
    importBtn.addEventListener('click', handleImportShortcuts);
  }

  if (importClearBtn) {
    importClearBtn.addEventListener('click', () => {
      if (importTextarea) {
        importTextarea.value = '';
        handleImportInputChange();
        importTextarea.focus();
      }
    });
  }

  if (exportBtn) {
    exportBtn.addEventListener('click', handleExportShortcuts);
  }

  function loadShortcuts() {
    chrome.storage.local.get(['shortcuts'], (result) => {
      if (result.shortcuts) {
        shortcuts = result.shortcuts;
      } else {
        shortcuts = getDefaultShortcuts();
        saveShortcuts();
      }
      renderAllShortcuts();
    });
  }

  function saveShortcuts() {
    chrome.storage.local.set({ shortcuts: shortcuts });
  }

  function renderAllShortcuts() {
    const list = document.getElementById('allShortcutList');
    list.innerHTML = '';

    if (shortcuts.length === 0) {
      const emptyTemplate = document.getElementById('empty-state-template');
      const emptyClone = emptyTemplate.content.cloneNode(true);
      list.appendChild(emptyClone);
      return;
    }

    shortcuts.forEach((shortcut, index) => {
      const template = document.getElementById('shortcut-item-template');
      const clone = template.content.cloneNode(true);

      clone.querySelector('.shortcut-item__key').textContent = shortcut.key;
      clone.querySelector('.shortcut-item__description').textContent = shortcut.description;
      clone.querySelector('.shortcut-item__url').textContent = shortcut.url;

      const editBtn = clone.querySelector('.icon-btn--edit');
      editBtn.addEventListener('click', () => editShortcut(index));

      const deleteBtn = clone.querySelector('.icon-btn--delete');
      deleteBtn.addEventListener('click', () => deleteShortcut(index));

      list.appendChild(clone);
    });
  }

  function deleteShortcut(index) {
    if (confirm('Are you sure you want to delete this shortcut?')) {
      const listItems = document.querySelectorAll('.shortcut-item');
      const itemToDelete = listItems[index];

      if (itemToDelete) {
        itemToDelete.classList.add('shortcut-item--deleting');

        setTimeout(() => {
          shortcuts.splice(index, 1);
          saveShortcuts();
          renderAllShortcuts();

          if (editingIndex === index) {
            cancelEdit();
          } else if (editingIndex !== null && editingIndex > index) {
            editingIndex--;
          }
        }, 800);
      } else {
        shortcuts.splice(index, 1);
        saveShortcuts();
        renderAllShortcuts();

        if (editingIndex === index) {
          cancelEdit();
        } else if (editingIndex !== null && editingIndex > index) {
          editingIndex--;
        }
      }
    }
  }

  function editShortcut(index) {
    const shortcut = shortcuts[index];

    document.getElementById('newKey').value = shortcut.key;
    document.getElementById('newDesc').value = shortcut.description;
    document.getElementById('newUrl').value = shortcut.url;

    editingIndex = index;
    document.getElementById('formTitle').textContent = 'Edit Shortcut';
    document.getElementById('addBtn').innerHTML = `
      <svg viewBox="0 0 24 24"><use href="components/icons.svg#icon-check"/></svg>
      Update Shortcut
    `;
    document.getElementById('cancelBtn').style.display = 'inline-flex';

    window.scrollTo({ top: 0, behavior: 'smooth' });

    document.getElementById('newKey').focus();
    validateForm();
  }

  function cancelEdit() {
    editingIndex = null;
    document.getElementById('newKey').value = '';
    document.getElementById('newDesc').value = '';
    document.getElementById('newUrl').value = '';

    document.getElementById('formTitle').textContent = 'Add New Shortcut';
    document.getElementById('addBtn').innerHTML = `
      <svg viewBox="0 0 24 24"><use href="components/icons.svg#icon-add"/></svg>
      Add Shortcut
    `;
    document.getElementById('cancelBtn').style.display = 'none';

    validateForm();
  }

  function validateForm() {
    const key = document.getElementById('newKey').value.trim();
    const url = document.getElementById('newUrl').value.trim();
    const addBtn = document.getElementById('addBtn');

    addBtn.disabled = !key || !url;
  }

  function saveShortcut() {
    const key = document.getElementById('newKey').value.trim();
    const desc = document.getElementById('newDesc').value.trim();
    const url = document.getElementById('newUrl').value.trim();

    if (key && url) {
      const existingIndex = shortcuts.findIndex(s => s.key === key);
      if (existingIndex !== -1 && existingIndex !== editingIndex) {
        showErrorMessage("A shortcut with this key already exists. Please delete/edit it first, or use a different key.");
        highlightDuplicate(existingIndex);
        return;
      }

      let savedIndex;
      if (editingIndex !== null) {
        shortcuts[editingIndex] = {
          key,
          description: desc || '',
          url
        };
        savedIndex = editingIndex;
      } else {
        shortcuts.push({
          key,
          description: desc || '',
          url
        });
        savedIndex = shortcuts.length - 1;
      }

      saveShortcuts();
      renderAllShortcuts();

      cancelEdit();

      highlightSaved(savedIndex);

      document.getElementById('newKey').focus();
    }
  }

  function showErrorMessage(message) {
    errorNotification.show(message);
  }

  function showSuccessMessage(message) {
    successNotification.show(message);
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function highlightDuplicate(index) {
    const listItems = document.querySelectorAll('.shortcut-item');
    if (listItems[index]) {
      const item = listItems[index];
      item.style.background = '#5a1d1d';
      item.style.borderColor = '#8b2d2d';
      item.style.transition = 'background 0.3s ease, border-color 0.3s ease';

      setTimeout(() => {
        item.style.background = '';
        item.style.borderColor = '';
      }, 4000);
    }
  }

  function highlightSaved(index) {
    const listItems = document.querySelectorAll('.shortcut-item');
    if (listItems[index]) {
      const item = listItems[index];
      item.classList.add('shortcut-item--highlight');

      item.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

      setTimeout(() => {
        item.classList.remove('shortcut-item--highlight');
      }, 2000);
    }
  }

  function handleImportInputChange() {
    if (!importBtn || !importTextarea) {
      return;
    }
    importBtn.disabled = !importTextarea.value.trim();
  }

  function handleImportShortcuts() {
    if (!importTextarea) {
      return;
    }

    const raw = importTextarea.value.trim();
    if (!raw) {
      handleImportInputChange();
      return;
    }

    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (error) {
      showErrorMessage('Invalid JSON. Please double-check your syntax.');
      return;
    }

    if (!Array.isArray(parsed) || parsed.length === 0) {
      showErrorMessage('JSON must be a non-empty array of shortcut objects.');
      return;
    }

    const importedKeys = new Set();
    const sanitizedEntries = [];

    for (const entry of parsed) {
      if (!entry || typeof entry !== 'object') {
        showErrorMessage('Each entry must be an object with "key" and "url" fields.');
        return;
      }

      const key = typeof entry.key === 'string' ? entry.key.trim() : '';
      const url = typeof entry.url === 'string' ? entry.url.trim() : '';
      const description =
        typeof entry.description === 'string' ? entry.description.trim() : '';

      if (!key || !url) {
        showErrorMessage('Every shortcut needs a non-empty key and url.');
        return;
      }

      importedKeys.add(key);
      sanitizedEntries.push({
        key,
        url,
        description
      });
    }

    shortcuts = [
      ...shortcuts.filter((shortcut) => !importedKeys.has(shortcut.key)),
      ...sanitizedEntries
    ];
    saveShortcuts();
    renderAllShortcuts();
    showSuccessMessage(`Imported ${sanitizedEntries.length} shortcut(s).`);

    importTextarea.value = '';
    handleImportInputChange();
  }

  function handleExportShortcuts() {
    const payload = shortcuts.map((shortcut) => ({
      key: shortcut.key,
      url: shortcut.url,
      description: shortcut.description || ''
    }));
    const json = JSON.stringify(payload, null, 2);

    if (importTextarea) {
      importTextarea.value = json;
      handleImportInputChange();
      importTextarea.focus();
      importTextarea.select();
    }

    copyJsonToClipboard(json);
  }

  function copyJsonToClipboard(text) {
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard
        .writeText(text)
        .then(() => showSuccessMessage('Shortcuts copied to clipboard.'))
        .catch(() => fallbackCopy(text));
      return;
    }
    fallbackCopy(text);
  }

  function fallbackCopy(text) {
    try {
      const temp = document.createElement('textarea');
      temp.value = text;
      document.body.appendChild(temp);
      temp.select();
      document.execCommand('copy');
      document.body.removeChild(temp);
      showSuccessMessage('Shortcuts copied to clipboard.');
    } catch (error) {
      showSuccessMessage('Export ready below—copy manually if needed.');
    }
  }
})();
