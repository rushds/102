const SAVE_SHORTCUT_COMMAND = 'save_page_shortcut';
const PENDING_SHORTCUT_STORAGE_KEY = 'pendingShortcutDraft';

chrome.commands.onCommand.addListener((command) => {
  if (command !== SAVE_SHORTCUT_COMMAND) {
    return;
  }
  handleSaveShortcutCommand();
});

async function handleSaveShortcutCommand() {
  try {
    const activeTab = await getActiveTab();
    if (!isTabEligible(activeTab)) {
      return;
    }
    await queueShortcutDraft(activeTab);
    await openQuickNavPopup();
  } catch (error) {
    console.error('Failed to start shortcut creation flow:', error);
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function isTabEligible(tab) {
  if (!tab || !tab.url) {
    return false;
  }
  return !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://');
}

async function queueShortcutDraft(tab) {
  const draft = {
    description: tab.title || '',
    url: tab.url || '',
    createdAt: Date.now()
  };
  await chrome.storage.local.set({
    [PENDING_SHORTCUT_STORAGE_KEY]: draft
  });
}

async function openQuickNavPopup() {
  if (!chrome.action || typeof chrome.action.openPopup !== 'function') {
    if (chrome.runtime && chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    }
    return;
  }

  try {
    await chrome.action.openPopup();
  } catch (error) {
    console.warn('Unable to open Quick Nav popup, falling back to options page.', error);
    if (chrome.runtime && chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    }
  }
}
