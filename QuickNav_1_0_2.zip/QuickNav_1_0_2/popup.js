const TUTORIAL_STORAGE_KEY = 'tutorialCompleted';
const SHORTCUT_DRAFT_STORAGE_KEY = 'pendingShortcutDraft';
let shortcuts = [];
let parsedUrl = '';
let renderedSignature = null;
let filteredShortcuts = [];
let activeShortcutIndex = -1;
let lastFocusedElement = null;
let currentShortcutMatch = null;
let validationFeedbackTimeout = null;
let variableInputState = null;
let shortcutModalLastFocusedElement = null;

const searchInput = document.getElementById('searchInput');
const goBtn = document.getElementById('goBtn');
const preview = document.getElementById('preview');
const previewUrl = document.getElementById('previewUrl');
const searchBox = document.querySelector('.search-box');
const addShortcutBtn = document.getElementById('addShortcutBtn');
const shortcutModal = document.getElementById('shortcutModal');
const shortcutModalBackdrop = document.getElementById('shortcutModalBackdrop');
const shortcutModalClose = document.getElementById('shortcutModalClose');
const shortcutForm = document.getElementById('shortcutForm');
const shortcutKeyInput = document.getElementById('shortcutKeyInput');
const shortcutDescInput = document.getElementById('shortcutDescInput');
const shortcutUrlInput = document.getElementById('shortcutUrlInput');
const shortcutModalError = document.getElementById('shortcutModalError');
const shortcutSaveBtn = document.getElementById('shortcutSaveBtn');
const shortcutCancelBtn = document.getElementById('shortcutCancelBtn');

loadShortcuts();


searchInput.addEventListener('input', (e) => {
  parseInput(e.target.value);
});

searchInput.addEventListener('keydown', handleInputNavigation);

goBtn.addEventListener('click', handleGo);

function openSettingsPage() {
  if (chrome.runtime && chrome.runtime.openOptionsPage) {
    chrome.runtime.openOptionsPage();
  } else {
    chrome.tabs.create({
      url: chrome.runtime.getURL('settings.html')
    });
  }
}

document.getElementById('helpBtn').addEventListener('click', () => {
  showTutorialModal();
});
document.getElementById('editShortcutsBtn').addEventListener('click', openSettingsPage);
setupTutorialModal();
setupShortcutModal();
initializePendingShortcutDraftHandling();

document.getElementById('shortcutsHeader').addEventListener('click', () => {
  const content = document.getElementById('shortcutsContent');
  const icon = document.querySelector('.popup-section__collapse-icon');
  
  content.classList.toggle('popup-section__content--collapsed');
  icon.classList.toggle('popup-section__collapse-icon--collapsed');
});

function loadShortcuts() {
    chrome.storage.local.get(['shortcuts'], (result) => {
      if (result.shortcuts) {
        shortcuts = result.shortcuts;
      } else {
        shortcuts = getDefaultShortcuts();
        saveShortcuts();
      }
      renderShortcuts();
    });
}

function saveShortcuts() {
    chrome.storage.local.set({ shortcuts: shortcuts });
}

function parseInput(text, options = {}) {
  const { preserveActiveSelection = false } = options;

  if (!preserveActiveSelection) {
    activeShortcutIndex = -1;
  }

  currentShortcutMatch = null;
  renderShortcuts(getFilteredShortcuts(text));

  const trimmedText = text.trim();

  if (!trimmedText) {
    preview.classList.add('hidden');
    goBtn.disabled = true;
    parsedUrl = '';
    updateActiveShortcutHighlight();
    return;
  }

  const sortedShortcuts = [...shortcuts].sort((a, b) => b.key.length - a.key.length);
  
  for (const shortcut of sortedShortcuts) {
    if (text.startsWith(shortcut.key + ' ') || text === shortcut.key) {
      const matchResult = createShortcutMatch(shortcut, text);
      currentShortcutMatch = matchResult;
      previewUrl.innerHTML = matchResult.displayHtml;
      preview.classList.remove('hidden');

      if (matchResult.isReady) {
        parsedUrl = matchResult.filledUrl;
        goBtn.disabled = false;
      } else {
        parsedUrl = '';
        goBtn.disabled = true;
      }
      return;
    }
  }
  
  if (looksLikeDirectNavigation(trimmedText)) {
    parsedUrl = trimmedText.toLowerCase().startsWith('http') ? trimmedText : `https://${trimmedText}`;
  } else {
    parsedUrl = `https://google.com/search?q=${encodeURIComponent(trimmedText)}`;
  }
  
  previewUrl.textContent = parsedUrl;
  preview.classList.remove('hidden');
  goBtn.disabled = false;
}

function handleGo() {
  if (submitShortcutIfPossible()) {
    return;
  }

  if (parsedUrl) {
    openUrlAndReset(parsedUrl);
  }
}

function getFilteredShortcuts(query) {
  const normalizedQuery = (query || '').toLowerCase().trim();
  if (!normalizedQuery) {
    return shortcuts;
  }
  const tokens = normalizedQuery.split(/\s+/).filter(Boolean);
  if (!tokens.length) {
    return shortcuts;
  }
  return shortcuts.filter((shortcut) => fuzzyMatchShortcut(shortcut, tokens));
}

function fuzzyMatchShortcut(shortcut, tokens) {
  const descriptionLower = (shortcut.description || '').toLowerCase();
  const urlLower = shortcut.url.toLowerCase();
  const haystack = `${shortcut.key.toLowerCase()} ${descriptionLower} ${urlLower}`; // allow partial matches across metadata
  return tokens.every((token) => haystack.includes(token));
}

/* Legacy exact-match filtering retained for easy rollback.
function getFilteredShortcuts(query) {
  const normalizedFullQuery = (query || '').toLowerCase();
  const normalizedQuery = normalizedFullQuery.trim();
  if (!normalizedQuery) {
    return shortcuts;
  }
  return shortcuts.filter(shortcut => isKeyMatch(normalizedFullQuery, normalizedQuery, shortcut.key.toLowerCase()));
}

function isKeyMatch(fullQuery, trimmedQuery, shortcutKey) {
  if (trimmedQuery.length <= shortcutKey.length) {
    return shortcutKey.startsWith(trimmedQuery);
  }
  if (!fullQuery.startsWith(shortcutKey)) {
    return false;
  }
  const nextChar = fullQuery.charAt(shortcutKey.length);
  return nextChar === ' ';
}
*/

function renderShortcuts(filteredList = shortcuts) {
  filteredShortcuts = filteredList;
  const list = document.getElementById('shortcutList');
  const signature = filteredList
    .map((shortcut) => `${shortcut.key}|${shortcut.url}|${shortcut.description || ''}`)
    .join('||');

  if (signature === renderedSignature) {
    syncActiveIndexWithList();
    updateActiveShortcutHighlight();
    return;
  }

  renderedSignature = signature;
  syncActiveIndexWithList();
  list.classList.add('popup-shortcut-list--updating');

  const fragment = document.createDocumentFragment();
  
  filteredList.forEach((shortcut, index) => {
    const item = document.createElement('div');
    const baseClass = 'popup-shortcut-item popup-shortcut-item--enter';
    item.className = baseClass + (index === activeShortcutIndex ? ' popup-shortcut-item--active' : '');
    item.dataset.shortcutIndex = index;
    item.innerHTML = `
      <div class="popup-shortcut-item__key">${shortcut.key}</div>
      <div class="popup-shortcut-item__info">
        <div class="popup-shortcut-item__description">${shortcut.description}</div>
        <div class="popup-shortcut-item__url">${shortcut.url}</div>
      </div>
    `;
    fragment.appendChild(item);
    requestAnimationFrame(() => {
      item.classList.remove('popup-shortcut-item--enter');
    });
  });

  list.innerHTML = '';
  list.appendChild(fragment);

  requestAnimationFrame(() => {
    list.classList.remove('popup-shortcut-list--updating');
    updateActiveShortcutHighlight();
    applyOverflowTooltips();
  });
}

function syncActiveIndexWithList() {
  if (!filteredShortcuts.length) {
    activeShortcutIndex = -1;
    return;
  }

  if (activeShortcutIndex >= filteredShortcuts.length) {
    activeShortcutIndex = filteredShortcuts.length - 1;
  }
}

function handleInputNavigation(event) {
  if (event.key === 'ArrowDown') {
    if (!filteredShortcuts.length) {
      return;
    }
    event.preventDefault();
    moveActiveShortcut(1);
  } else if (event.key === 'ArrowUp') {
    if (!filteredShortcuts.length) {
      return;
    }
    event.preventDefault();
    moveActiveShortcut(-1);
  } else if (event.key === 'Enter') {
    if (activeShortcutIndex >= 0) {
      const shortcut = filteredShortcuts[activeShortcutIndex];
      if (shortcut && shouldApplyShortcutSelection(shortcut)) {
        event.preventDefault();
        applyShortcutSelection(shortcut);
        return;
      }
    }
    event.preventDefault();
    handleGo();
  }
}

function moveActiveShortcut(delta) {
  if (!filteredShortcuts.length) {
    return;
  }

  if (activeShortcutIndex === -1) {
    activeShortcutIndex = delta > 0 ? 0 : filteredShortcuts.length - 1;
  } else {
    activeShortcutIndex = (activeShortcutIndex + delta + filteredShortcuts.length) % filteredShortcuts.length;
  }

  updateActiveShortcutHighlight();
  scrollActiveShortcutIntoView();
}

function applyShortcutSelection(shortcut) {
  const requiresInput = shortcutRequiresInput(shortcut);
  const trailingSpace = requiresInput && !shortcut.key.endsWith(' ') ? ' ' : '';
  activeShortcutIndex = -1;
  searchInput.value = `${shortcut.key}${trailingSpace}`;
  parseInput(searchInput.value, { preserveActiveSelection: true });
  updateActiveShortcutHighlight();

  if (!requiresInput) {
    handleGo();
    return;
  }

  requestAnimationFrame(() => {
    searchInput.focus();
    const cursorPos = searchInput.value.length;
    searchInput.setSelectionRange(cursorPos, cursorPos);
  });
}

function shouldApplyShortcutSelection(shortcut) {
  const normalizedKey = shortcut.key.toLowerCase();
  const normalizedValue = searchInput.value.trim().toLowerCase();

  if (!normalizedValue) {
    return true;
  }

  if (normalizedKey.startsWith(normalizedValue) && normalizedValue !== normalizedKey) {
    return true;
  }

  if (normalizedValue === normalizedKey && !searchInput.value.endsWith(' ')) {
    return true;
  }

  return false;
}

function updateActiveShortcutHighlight() {
  const list = document.getElementById('shortcutList');
  if (!list) {
    return;
  }
  const items = list.querySelectorAll('.popup-shortcut-item');
  items.forEach((item, index) => {
    item.classList.toggle('popup-shortcut-item--active', activeShortcutIndex === index && activeShortcutIndex !== -1);
  });
}

function scrollActiveShortcutIntoView() {
  const list = document.getElementById('shortcutList');
  if (!list) {
    return;
  }
  const activeItem = list.querySelector('.popup-shortcut-item--active');
  if (activeItem) {
    activeItem.scrollIntoView({ block: 'nearest' });
  }
}

function createShortcutMatch(shortcut, text) {
  const template = shortcut.url;
  const variableMatches = [...template.matchAll(/\{([^}]+)\}/g)];
  const replacementValues = variableMatches.map(() => null);
  const remainder = text.slice(shortcut.key.length).trim();

  if (variableMatches.length === 1 && remainder) {
    replacementValues[0] = remainder;
  } else if (variableMatches.length > 1 && remainder) {
    const values = remainder.split(/[,\s]+/).filter((v) => v);
    variableMatches.forEach((_, index) => {
      const value = values[index];
      if (value) {
        replacementValues[index] = value;
      }
    });
  }

  const overrides =
    variableInputState && variableInputState.shortcutKey === shortcut.key
      ? variableInputState.values
      : null;

  if (overrides) {
    overrides.forEach((overrideValue, index) => {
      if (Object.prototype.hasOwnProperty.call(overrides, index)) {
        replacementValues[index] = overrideValue;
      }
    });
  }

  const filledUrl = buildFilledUrl(template, variableMatches, replacementValues);
  const displayHtml = buildDisplayHtml(template, variableMatches, replacementValues);
  const missingVariables = variableMatches.some((_, index) => !replacementValues[index]);
  const placeholders = variableMatches.map((match, index) => ({
    name: match[1],
    value: replacementValues[index] || '',
    missing: !replacementValues[index],
    index
  }));

  return {
    shortcut,
    filledUrl,
    displayHtml,
    requiresInput: variableMatches.length > 0,
    placeholders,
    placeholderValues: [...replacementValues],
    missingVariables,
    isReady: !missingVariables
  };
}

function renderVariableInputs(match, options = {}) {
  if (!variableInputs) {
    return;
  }

  if (!match || !match.requiresInput) {
    variableInputs.classList.add('hidden');
    variableInputs.innerHTML = '';
    return;
  }

  const { refocusIndex = null, refocusCursor = null } = options;
  variableInputs.innerHTML = '';
  variableInputs.classList.remove('hidden');

  match.placeholders.forEach((placeholder, index) => {
    const chip = document.createElement('label');
    chip.className = 'variable-chip';
    if (placeholder.missing) {
      chip.classList.add('variable-chip--missing');
    }

    const label = document.createElement('span');
    label.className = 'variable-chip__label';
    label.textContent = placeholder.name;

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'variable-chip__input';
    input.dataset.placeholderIndex = String(index);
    input.value = placeholder.value || '';
    input.placeholder = placeholder.name;
    input.addEventListener('input', handleVariableInput);

    chip.appendChild(label);
    chip.appendChild(input);
    variableInputs.appendChild(chip);
  });

  if (typeof refocusIndex === 'number') {
    const targetInput = variableInputs.querySelector(
      `.variable-chip__input[data-placeholder-index="${refocusIndex}"]`
    );
    if (targetInput) {
      const cursorPosition =
        typeof refocusCursor === 'number'
          ? Math.min(refocusCursor, targetInput.value.length)
          : targetInput.value.length;
      requestAnimationFrame(() => {
        targetInput.focus();
        targetInput.setSelectionRange(cursorPosition, cursorPosition);
      });
    }
  }
}

function handleVariableInput(event) {
  if (!currentShortcutMatch) {
    return;
  }
  const input = event.target;
  const placeholderIndex = Number(input.dataset.placeholderIndex);
  if (Number.isNaN(placeholderIndex)) {
    return;
  }

  const cursorPosition = input.selectionStart ?? input.value.length;
  const shortcutKey = currentShortcutMatch.shortcut.key;
  const existingValues =
    variableInputState && variableInputState.shortcutKey === shortcutKey
      ? [...variableInputState.values]
      : currentShortcutMatch.placeholders.map((placeholder) => placeholder.value || '');

  existingValues[placeholderIndex] = input.value;
  variableInputState = {
    shortcutKey,
    values: existingValues
  };

  parseInput(searchInput.value, {
    preserveActiveSelection: true,
    refocusPlaceholderIndex: placeholderIndex,
    refocusCursor: cursorPosition,
    fromVariableInput: true
  });
}

function submitShortcutIfPossible() {
  if (currentShortcutMatch) {
    if (currentShortcutMatch.isReady) {
      openUrlAndReset(currentShortcutMatch.filledUrl);
    } else {
      indicateMissingVariables();
    }
    return true;
  }

  const inputValue = searchInput.value.trim();
  if (!inputValue || looksLikeDirectNavigation(inputValue)) {
    return false;
  }

  const candidate = getShortcutSubmissionCandidate();
  if (!candidate) {
    return false;
  }

  if (shortcutRequiresInput(candidate)) {
    applyShortcutSelection(candidate);
    indicateMissingVariables();
    return true;
  }

  openUrlAndReset(candidate.url);
  return true;
}

function getShortcutSubmissionCandidate() {
  if (!filteredShortcuts.length) {
    return null;
  }
  if (activeShortcutIndex >= 0 && filteredShortcuts[activeShortcutIndex]) {
    return filteredShortcuts[activeShortcutIndex];
  }
  return filteredShortcuts[0];
}

function shortcutRequiresInput(shortcut) {
  return /\{[^}]+\}/.test(shortcut.url);
}

function openUrlAndReset(url) {
  if (!url) {
    return;
  }
  window.open(url, '_blank');
  searchInput.value = '';
  parseInput('');
}

function looksLikeDirectNavigation(text = '') {
  if (!text) {
    return false;
  }
  const normalized = text.trim().toLowerCase();
  return normalized.startsWith('http://') || normalized.startsWith('https://') || normalized.includes('.');
}

function indicateMissingVariables() {
  if (!searchBox) {
    return;
  }
  searchBox.classList.remove('search-box--shake');
  void searchBox.offsetWidth;
  searchBox.classList.add('search-box--shake');
  if (validationFeedbackTimeout) {
    clearTimeout(validationFeedbackTimeout);
  }
  validationFeedbackTimeout = setTimeout(() => {
    searchBox.classList.remove('search-box--shake');
  }, 500);
}

function buildFilledUrl(template, matches, replacementValues) {
  return buildTemplateString(template, matches, replacementValues, {
    formatLiteral: (text) => text,
    formatValue: (value) => value
  });
}

function setupShortcutModal() {
  if (!shortcutModal || !shortcutForm) {
    return;
  }

  shortcutModal.setAttribute('inert', '');

  if (addShortcutBtn) {
    addShortcutBtn.addEventListener('click', () => {
      showShortcutModal();
    });
  }

  if (shortcutModalClose) {
    shortcutModalClose.addEventListener('click', hideShortcutModal);
  }

  if (shortcutModalBackdrop) {
    shortcutModalBackdrop.addEventListener('click', hideShortcutModal);
  }

  if (shortcutCancelBtn) {
    shortcutCancelBtn.addEventListener('click', hideShortcutModal);
  }

  shortcutForm.addEventListener('input', validateShortcutModalForm);
  shortcutForm.addEventListener('submit', handleShortcutModalSubmit);
}

function showShortcutModal(preset = {}) {
  if (!shortcutModal || !shortcutForm) {
    return;
  }

  shortcutModalLastFocusedElement = document.activeElement;
  shortcutModal.removeAttribute('inert');
  shortcutModal.classList.add('shortcut-modal--visible');
  shortcutModal.setAttribute('aria-hidden', 'false');

  if (shortcutKeyInput) {
    shortcutKeyInput.value = '';
  }
  if (shortcutDescInput) {
    shortcutDescInput.value = preset.description || '';
  }
  if (shortcutUrlInput) {
    shortcutUrlInput.value = preset.url || '';
  }

  if (shortcutModalError) {
    shortcutModalError.textContent = '';
  }
  validateShortcutModalForm();

  requestAnimationFrame(() => {
    if (shortcutKeyInput) {
      shortcutKeyInput.focus();
    }
  });
}

function hideShortcutModal() {
  if (!shortcutModal || !shortcutForm) {
    return;
  }

  shortcutModal.classList.remove('shortcut-modal--visible');
  shortcutModal.setAttribute('aria-hidden', 'true');
  shortcutModal.setAttribute('inert', '');
  shortcutForm.reset();
  if (shortcutModalError) {
    shortcutModalError.textContent = '';
  }
  if (shortcutSaveBtn) {
    shortcutSaveBtn.disabled = true;
  }

  const focusTarget =
    shortcutModalLastFocusedElement && document.contains(shortcutModalLastFocusedElement)
      ? shortcutModalLastFocusedElement
      : searchInput;
  if (focusTarget && typeof focusTarget.focus === 'function') {
    focusTarget.focus();
  }
  shortcutModalLastFocusedElement = null;
}

function validateShortcutModalForm() {
  if (!shortcutForm || !shortcutSaveBtn || !shortcutModalError) {
    return;
  }

  const keyValue = (shortcutKeyInput?.value || '').trim();
  const urlValue = (shortcutUrlInput?.value || '').trim();
  let error = '';

  if (!keyValue || !urlValue) {
    error = 'Shortcut key and URL are required.';
  } else if (shortcuts.some((shortcut) => shortcut.key === keyValue)) {
    error = 'That shortcut key already exists.';
  }

  shortcutModalError.textContent = error;
  shortcutSaveBtn.disabled = Boolean(error);
}

function handleShortcutModalSubmit(event) {
  event.preventDefault();
  if (!shortcutForm) {
    return;
  }

  validateShortcutModalForm();
  if (shortcutSaveBtn && shortcutSaveBtn.disabled) {
    return;
  }

  const key = (shortcutKeyInput?.value || '').trim();
  const description = (shortcutDescInput?.value || '').trim();
  const url = (shortcutUrlInput?.value || '').trim();

  if (!key || !url) {
    return;
  }

  shortcuts.push({
    key,
    description,
    url
  });
  saveShortcuts();
  renderShortcuts(getFilteredShortcuts(searchInput.value));
  hideShortcutModal();
}

function initializePendingShortcutDraftHandling() {
  if (!chrome?.storage?.local) {
    return;
  }

  chrome.storage.local.get([SHORTCUT_DRAFT_STORAGE_KEY], (result) => {
    const draft = result[SHORTCUT_DRAFT_STORAGE_KEY];
    if (draft) {
      chrome.storage.local.remove(SHORTCUT_DRAFT_STORAGE_KEY);
      showShortcutModalFromDraft(draft);
    }
  });

  if (chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== 'local' || !Object.prototype.hasOwnProperty.call(changes, SHORTCUT_DRAFT_STORAGE_KEY)) {
        return;
      }
      const change = changes[SHORTCUT_DRAFT_STORAGE_KEY];
      if (change?.newValue) {
        showShortcutModalFromDraft(change.newValue);
        chrome.storage.local.remove(SHORTCUT_DRAFT_STORAGE_KEY);
      }
    });
  }
}

function showShortcutModalFromDraft(draft) {
  showShortcutModal({
    description: draft?.description || '',
    url: draft?.url || ''
  });
}

function buildDisplayHtml(template, matches, replacementValues) {
  return buildTemplateString(template, matches, replacementValues, {
    formatLiteral: (text) => escapeHtml(text),
    formatValue: (value) => `<span class="preview-highlight">${escapeHtml(value)}</span>`,
    formatPlaceholder: (placeholderText) => `<span class="preview-placeholder preview-placeholder--missing">${escapeHtml(placeholderText)}</span>`
  });
}

function buildTemplateString(template, matches, replacementValues, formatters) {
  const formatLiteral = formatters.formatLiteral;
  const formatValue = formatters.formatValue;
  const formatPlaceholder = formatters.formatPlaceholder || formatLiteral;

  if (!matches.length) {
    return formatLiteral(template);
  }

  let result = '';
  let lastIndex = 0;

  matches.forEach((match, index) => {
    const start = match.index;
    const end = start + match[0].length;
    if (start > lastIndex) {
      result += formatLiteral(template.slice(lastIndex, start));
    }
    const value = replacementValues[index];
    if (value) {
      result += formatValue(value);
    } else {
      result += formatPlaceholder(template.slice(start, end));
    }
    lastIndex = end;
  });

  if (lastIndex < template.length) {
    result += formatLiteral(template.slice(lastIndex));
  }

  return result;
}

function escapeHtml(text = '') {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function setupTutorialModal() {
  const modal = document.getElementById('tutorialModal');
  if (!modal) {
    return;
  }
  modal.setAttribute('inert', '');

  const backdrop = modal.querySelector('.tutorial-modal__backdrop');
  const dismissBtn = document.getElementById('tutorialDismissBtn');
  const gotItBtn = document.getElementById('tutorialGotItBtn');
  const editBtn = document.getElementById('tutorialEditShortcutsBtn');

  const closeAndMarkSeen = () => hideTutorialModal(true);

  [backdrop, dismissBtn, gotItBtn].forEach((el) => {
    if (el) {
      el.addEventListener('click', closeAndMarkSeen);
    }
  });

  if (editBtn) {
    editBtn.addEventListener('click', () => {
      hideTutorialModal(true);
      openSettingsPage();
    });
  }

  chrome.storage.local.get([TUTORIAL_STORAGE_KEY], (result) => {
    if (!result[TUTORIAL_STORAGE_KEY]) {
      showTutorialModal();
    }
  });
}

function showTutorialModal() {
  const modal = document.getElementById('tutorialModal');
  if (!modal) {
    return;
  }
  lastFocusedElement = document.activeElement;
  modal.removeAttribute('inert');
  modal.classList.add('tutorial-modal--visible');
  modal.setAttribute('aria-hidden', 'false');
  const initialFocusTarget = document.getElementById('tutorialDismissBtn') || modal.querySelector('button');
  if (initialFocusTarget) {
    initialFocusTarget.focus();
  }
}

function hideTutorialModal(markSeen = false) {
  const modal = document.getElementById('tutorialModal');
  if (!modal) {
    return;
  }
  modal.classList.remove('tutorial-modal--visible');
  modal.setAttribute('aria-hidden', 'true');
  modal.setAttribute('inert', '');
  const targetToFocus = lastFocusedElement && document.contains(lastFocusedElement) ? lastFocusedElement : searchInput;
  if (targetToFocus && typeof targetToFocus.focus === 'function') {
    targetToFocus.focus();
  }
  lastFocusedElement = null;

  if (markSeen) {
    chrome.storage.local.set({ [TUTORIAL_STORAGE_KEY]: true });
  }
}

window.addEventListener('resize', () => {
  applyOverflowTooltips();
});

function applyOverflowTooltips() {
  const elements = document.querySelectorAll('.popup-shortcut-item__description, .popup-shortcut-item__url');
  elements.forEach((el) => {
    const isOverflowing = el.scrollWidth - el.clientWidth > 1;
    if (isOverflowing) {
      el.setAttribute('title', el.textContent);
    } else {
      el.removeAttribute('title');
    }
  });
}
